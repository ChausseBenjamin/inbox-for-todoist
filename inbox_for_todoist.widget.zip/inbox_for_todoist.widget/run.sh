export LANG=en_CA.UTF-8;
python3 todoist/todoistinbox.py
